package com.whueric.dataonoff;

import android.content.Context;

/**
 * Created by echunwu on 2014-07-14.
 */
public class NetworkAdmin
{
    protected Context m_context = null;

    public NetworkAdmin(Context m_context)
    {
        this.m_context = m_context;

    }
}
